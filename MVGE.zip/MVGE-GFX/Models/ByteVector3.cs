﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVGE_GFX.Models
{
    public struct ByteVector3
    {
        public byte x;
        public byte y;
        public byte z;
    }
}
