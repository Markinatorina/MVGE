﻿namespace MVGE_INF.Models.Terrain
{
    public enum BlockStateOfMatter
    {
        Solid,
        Liquid,
        Gas
    }
}
