# MVGE
A .NET voxel render engine by me, with plans to develop into a full blown multiplayer game engine as a learning project.
